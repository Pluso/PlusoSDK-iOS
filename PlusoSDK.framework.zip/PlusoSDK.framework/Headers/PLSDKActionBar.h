//
//  PLSDKActionBar.h
//  PlusoSDK
//
//  Created by Alexey Sidorov on 20/05/15.
//  Copyright (c) 2015 RusVe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PLSDKConstants.h"

@class PLSDKActionBar;


@protocol PLSDKActionBarDelegate <NSObject>

@required
/**
 *  Called when user taped to close button
 *
 *  @param actionBar instance
 */
- (void)PLSDKActionBarShouldBeClosed:(PLSDKActionBar *)actionBar;

@optional
/**
 *  called after user rated app
 *
 *  @param actionBar instance
 *  @param rate      user`s rate from 1 to 5
 */
- (void)PLSDKActionBar:(PLSDKActionBar *)actionBar ratedWithRate:(NSUInteger)rate;
/**
 *  called after user shared an app url
 *
 *  @param actionBar instance
 *  @param provider  PLSDKShareProvider
 */
- (void)PLSDKActionBar:(PLSDKActionBar *)actionBar sharedWithProvider:(PLSDKShareProvider)provider;

@end


@protocol PLSDKShareViewDelegate;


@interface PLSDKActionBar : UIView <PLSDKShareViewDelegate>

@property (nonatomic, weak) id<PLSDKActionBarDelegate> delegate;

/**
 *  UIColor of action bar
 */
@property (nonatomic, strong) IBInspectable UIColor *barColor;

/**
 *  UIColor of buttons on bar
 */
@property (nonatomic, strong) IBInspectable UIColor *buttonsColor;

/**
 *  Action bar type
 */
@property (nonatomic, assign) IBInspectable PLSDKActivityType type;

/**
 *  URL string of your app in AppStore
 */
@property (nonatomic, strong) IBInspectable NSString *shareURLString;

/**
 *  used to User Defined Attribute at runtime
 */
@property (nonatomic, strong) IBInspectable NSString *actionType;

/**
 *  Email to send feedback from users
 */
@property (nonatomic, strong) IBInspectable NSString *feedbackEmail;

@end
