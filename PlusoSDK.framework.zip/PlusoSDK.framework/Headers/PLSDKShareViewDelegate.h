//
//  PLSDKShareViewDelegate.h
//  PlusoSDK
//
//  Created by Alexey Sidorov on 15/06/15.
//  Copyright (c) 2015 RusVe. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "PLSDKConstants.h"

@class PLSDKShareView;

@protocol PLSDKShareViewDelegate <NSObject>

@optional
- (void)PLSDKShareView:(PLSDKShareView *)shareView sharedWithProvider:(PLSDKShareProvider)provider;

@end